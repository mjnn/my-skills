#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
环境预检脚本：svw-ppt-generator
检查所有 Python 依赖是否已安装
"""

import sys

def check():
    errors = []

    # 核心依赖
    try:
        import pptx
        print(f"[OK] python-pptx 已安装 (版本: {pptx.__version__})")
    except ImportError:
        errors.append("[ERROR] python-pptx 未安装。请执行: pip install python-pptx")

    try:
        import matplotlib
        print(f"[OK] matplotlib 已安装 (版本: {matplotlib.__version__})")
    except ImportError:
        errors.append("[ERROR] matplotlib 未安装。请执行: pip install matplotlib")

    try:
        import PIL
        print(f"[OK] Pillow 已安装 (版本: {PIL.__version__})")
    except ImportError:
        errors.append("[ERROR] Pillow 未安装。请执行: pip install Pillow")

    # 可选依赖
    try:
        import playwright
        print(f"[OK] playwright 已安装（可选，用于HTML图表渲染）")
    except ImportError:
        print("[INFO] playwright 未安装（可选）。如需HTML图表渲染: pip install playwright && playwright install chromium")

    # 模板文件检查
    import os
    skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    template_path = os.path.join(skill_dir, "templates", "模板.pptx")
    if os.path.exists(template_path):
        print(f"[OK] 模板文件存在: {template_path}")
    else:
        errors.append(f"[ERROR] 模板文件不存在: {template_path}")

    chart_template = os.path.join(skill_dir, "templates", "全品类图表模板_v1.0.html")
    if os.path.exists(chart_template):
        print(f"[OK] 图表模板文件存在: {chart_template}")
    else:
        print(f"[INFO] 图表模板文件不存在（可选）: {chart_template}")

    if errors:
        print("\n--- 环境检查未通过 ---")
        for e in errors:
            print(e)
        sys.exit(1)
    else:
        print("\n--- 环境检查通过，可以正常使用 svw-ppt-generator ---")
        sys.exit(0)

if __name__ == "__main__":
    check()
