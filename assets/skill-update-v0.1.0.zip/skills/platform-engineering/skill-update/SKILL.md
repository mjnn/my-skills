---
name: skill-update
description: 当用户要求更新、修改、迭代或升级已有 Agent Skill 时触发。引导按门禁流程完成变更分析、版本判定、正文+eval 同步更新、自检、发布全链路。不适用于：从零创建新 skill（走 skill-bootstrap）、仅讨论 skill 设计不修改、评估第三方 skill（走 skill-audit）、skill 归档管理。
---

# Skill 更新引导

引导作者按门禁流程更新一个已有 Agent Skill。更新不是"改完就推"，而是"分析变更 → 同步更新 → 门禁检查 → 版本管理 → 发布"。

<HARD-GATE>
1. 在用户审核 Spec 并调用 ExitSpecMode 确认前，禁止修改任何 skill 文件。
2. 涉及信息收集时，必须使用 AskUserQuestion 工具提供结构化选项，禁止纯文本提问。
3. 发布前必须完成 13 项自检清单，禁止跳过自检直接 commit + push。
</HARD-GATE>

## Gotchas

1. **直接修改 SKILL.md 不走 Spec 模式** — Agent 拿到更新需求后直接改文件，用户无法在执行前审核变更范围。**纠正：必须调用 EnterSpecMode 生成变更计划，列出每个文件的修改内容、版本号判定、eval 更新需求，用户审核 ExitSpecMode 确认后才能修改。**

2. **改了正文不更新 eval** — 修改了 SKILL.md 的流程步骤但忘了同步更新 evals.json 和 eval_queries.json，导致 eval 与正文脱节。**纠正：每次修改正文模块后必须检查对应 eval 是否需要更新。修改了流程 → 更新 evals.json；修改了 description → 更新 eval_queries.json。**

3. **版本号判定错误** — 修改了 description 或新增了 Gotchas 应该是 minor，但只升了 patch。或者修改了核心流程结构应该是 major 但只升了 minor。**纠正：严格按照版本号判定规则对照变更内容确定版本类型，在 Spec 中明确标注版本号及判定依据。**

4. **发布新 Release 不删旧 Release** — 创建了新版本 Release 但历史版本 Release 仍然保留在 Release 页面。**纠正：发布新 Release 后必须通过 DELETE API 删除旧版本 Release，保持 Release 页面只展示最新版本。**

5. **README 和 CATALOG 版本不同步** — 升级了 skill 版本但 README.md 的版本号、Release 链接、git clone 命令三者没有同步更新。**纠正：每次版本变更后必须同步更新 README.md 已上架 Skill 表格和 CATALOG.md 注册表，确保版本号、Release 链接、git clone 命令三者一致。**

6. **跳过自检直接发布** — 修改完 SKILL.md 就直接 commit + push + tag，没有跑 13 项自检清单。**纠正：发布前必须完成自检清单全部 13 项通过，包括正文行数 ≤ 500、Gotchas ≥ 5 条、eval ≥ 3 条、触发测试 ≥ 16 条等硬性指标。**

7. **修改 description 不检查触发测试覆盖** — 更新了 description 的触发条件但没检查 eval_queries.json 中的测试用例是否仍然匹配。**纠正：修改 description 后必须重新审视所有触发测试用例，确保 should-trigger 和 should-not-trigger 的 reason 仍然成立，必要时补充新的 near-miss。**

## 流程

### 阶段一：信息收集

使用 AskUserQuestion 工具收集以下信息（单次调用，4 个问题）：

| 问题 | header | 选项 |
|------|--------|------|
| 要更新哪个 skill？ | 技能名称 | 列出仓库中已有 skill / 其他 |
| 变更类型是什么？ | 变更类型 | 修改正文流程 / 新增 Gotchas / 修改 description / 修改 eval / 修复 bug / 其他 |
| 是否需要更新 eval？ | eval 同步 | 是-同步更新（推荐） / 否-仅改正文 |
| 预期版本号？ | 版本号 | patch / minor / major / 不确定 |

用户通过 "Other" 可自由输入任意回答。

### 阶段二：变更分析

读取目标 skill 的当前文件：

1. 读取 `SKILL.md`，分析当前结构（行数、Gotchas 数、eval 数）
2. 读取 `evals/evals.json`，统计当前 eval 用例数
3. 读取 `evals/eval_queries.json`，统计当前触发测试数
4. 根据变更类型，确定需要修改的文件清单

**版本号判定规则：**

| 变更内容 | 版本类型 | 示例 |
|---------|---------|------|
| 仅修改 evals/、gotchas 措辞、references/ | patch（0.x.Y） | 修正 eval 断言、补充 gotcha 描述 |
| 修改 description、新增 gotchas、新增 eval 用例 | minor（0.X.0） | 新增 Gotcha、修改触发条件 |
| 修改 name、修改核心流程结构 | major（X.0.0） | 重构流程、重命名 skill |

### 阶段三：Spec 模式计划审核

信息收集和变更分析完成后，必须调用 EnterSpecMode 进入 spec 模式。

Spec 内容必须包含：
1. **变更清单**：每个文件的具体修改内容（SKILL.md / evals.json / eval_queries.json / references/）
2. **版本号判定**：新版本号 + 判定依据（对照版本号判定规则）
3. **eval 同步计划**：哪些 eval 用例需要新增/修改/删除
4. **触发测试同步计划**：哪些触发测试需要新增/修改/删除
5. **自检预估**：预估变更后 Gotchas 数、eval 数、触发测试数、正文行数
6. **发布计划**：tag 名称、Release 描述大纲、需删除的旧 Release

用户审核后调用 ExitSpecMode 确认，才能进入下一阶段。

### 阶段四：执行变更

按 Spec 计划逐个文件修改：

**步骤 1：修改 SKILL.md**
- 按 Spec 中的变更清单修改对应章节
- 修改后检查正文行数 ≤ 500

**步骤 2：同步更新 evals.json**
- 新增/修改/删除 eval 用例，与正文变更同步
- 确保每条用例有 prompt + expected_output + assertions（≥ 2 条）

**步骤 3：同步更新 eval_queries.json**
- 如果 description 变更：重新审视所有触发测试的 reason
- 新增/修改/删除触发测试用例
- 确保 should-trigger ≥ 8 条，should-not-trigger ≥ 8 条（含 ≥ 4 near-miss）

**步骤 4：更新 references/（如适用）**
- 如果变更涉及参考资料，同步更新 references/ 中的文件

### 阶段五：自检清单

所有变更完成后，逐项核对：

```
[ ] 1. SKILL.md 存在且 frontmatter 包含 name 和 description
[ ] 2. name 与父目录名一致，仅含小写字母/数字/连字符
[ ] 3. description 使用了命令式，含触发关键词和不应触发的边界说明
[ ] 4. 正文包含具体的操作步骤（非泛泛的"适当处理"）
[ ] 5. 包含 ≥ 5 条 Gotchas（基于真实经验）
[ ] 6. evals/evals.json 存在且含 ≥ 3 条用例
[ ] 7. 每条用例有 prompt + expected_output + assertions（≥ 2 条/用例）
[ ] 8. evals/eval_queries.json 存在且含 ≥ 16 条（含 ≥ 4 条 near-miss）
[ ] 9. SKILL.md 正文 ≤ 500 行（超出部分已拆分到 references/）
[ ] 10. 不含硬编码密钥/密码/Token 或内网 IP
[ ] 11. 正文末尾包含「执行后复盘（自迭代钩子）」章节
[ ] 12. 如 skill 涉及向用户提问，正文中明确指示使用 AskUserQuestion 工具
[ ] 13. 如 skill 涉及执行动作，正文中明确指示使用 EnterSpecMode/ExitSpecMode
```

**全部通过才能进入下一阶段。**

### 阶段六：格式预检

- frontmatter 字段完整性（name + description）
- description 长度 ≤ 1024
- name 命名规范（小写字母+数字+连字符）
- 正文行数 ≤ 500

### 阶段七：版本管理与发布

**步骤 5：提交代码**
```bash
git -C "<repo_path>" add skills/<domain>/<skill-name>/
git -C "<repo_path>" commit -m "Update <skill-name> to v<version>: <change_summary>"
git -C "<repo_path>" push origin main
```

**步骤 6：创建 Tag**
```bash
git -C "<repo_path>" tag "<skill-name>/v<version>"
git -C "<repo_path>" push origin "<skill-name>/v<version>"
```

**步骤 7：创建 Release（GitLab API）**

Release 描述必须包含完整信息，禁止使用 "Initial release" 等简单描述。description 必须包含：技能描述、核心功能、质量指标（Gotchas/Eval/触发测试数量）、关键 Gotchas、拉取方式（git clone 命令）、技能路径。

```bash
curl -s -X POST "https://<host>/api/v4/projects/<project_id>/releases" \
  -H "PRIVATE-TOKEN: <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "tag_name": "<skill-name>/v<version>",
    "name": "<skill-name> v<version>",
    "description": "<release_description>"
  }'
```

**步骤 8：删除旧版本 Release**

发布新版本 Release 后，必须删除旧版本的 Release，确保 Release 页面只展示最新版本。

```bash
curl -s -X DELETE "https://<host>/api/v4/projects/<project_id>/releases/<skill-name>%2Fv<old_version>" \
  -H "PRIVATE-TOKEN: <token>"
```

> **注意**：此操作仅删除 Release 元数据，不会删除 git tag。tag 保留在仓库中作为历史记录。

**步骤 9：更新 README.md 和 CATALOG.md**

同步更新 README.md 已上架 Skill 表格和 CATALOG.md 注册表：
- 版本号
- Release 链接
- git clone 命令
- 触发场景描述
- 最后更新日期

> **版本信息同步规范**：README.md 中的版本号、Release 链接和 git clone 命令三者必须保持一致。

### 阶段八：异常处理

| 异常场景 | 处理方式 |
|---------|---------|
| 自检清单有项不通过 | 返回阶段四修正，禁止跳过 |
| 正文超过 500 行 | 拆分到 references/，重新自检 |
| 版本号判定不确定 | 按最保守规则处理（就高不就低） |
| Release 创建失败 | 检查 tag 是否已推送，重试 |
| 旧 Release 删除失败（403） | 提示用户检查 token 权限，记录失败项 |
| README/CATALOG 更新遗漏 | 使用 grep 检查所有版本号引用是否一致 |

## 执行后复盘（自迭代钩子）

每次完成本 skill 的全部步骤后，Agent 必须自动执行以下动作，不询问用户：

1. **反思**：本轮执行中，是否遇到了 skill 正文和 Gotchas 都没覆盖的坑？触发条件：
   - Gotchas 中没写但实际踩了的错误
   - description 的排除场景遗漏导致误触发
   - 某个操作步骤的异常分支没覆盖

2. **记录**：有则追加到 `evals/PITFALLS_LOG.md`，无则跳过。格式：

| 日期 | 场景摘要 | 犯了什么错误 | 如果早知道__就不会犯 | 临时补救方式 |
|------|---------|-------------|-------------------|------------|
| YYYY-MM-DD | 一句话 | Agent 具体做了什么 | 缺失的知识/规则 | 怎么绕过去的 |

3. **不提交**：`PITFALLS_LOG.md` 是个人本地文件，不提交到 skill registry。积累 ≥ 3 条同类型坑后，由维护者提炼为正式 Gotchas，更新 SKILL.md 并走迭代管线。

> 这个复盘步骤不打断用户工作流。Agent 在后台完成，用户无感知。
